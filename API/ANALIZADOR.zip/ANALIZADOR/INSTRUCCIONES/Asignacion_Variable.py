from typing import List

from ..GENERAL.generator import Generador

from ..ABSTRACT.Retorno import Retorno
from ..ABSTRACT.instruccion import Instruccion
from ..ABSTRACT.NodoAST import NodoAST
from ..GENERAL.Arbol import Arbol
from ..GENERAL.table import Tabla
from ..GENERAL.Tipo import Tipos
from ..GENERAL.error import Error
from ..GENERAL.Simbolo import Simbolo

class Imprimir(Instruccion):

    def __init__(self, id,expresion, fila, columna, required_type=None):
        super().__init__(Tipos.STRING, fila, columna)
        self.id = id
        self.expresion = expresion
        self.required_type = required_type
        
    def Ejecutar(self, arbol: Arbol, tabla: Tabla):
        genAux = Generador()
        generador = genAux.get_instance()
        if isinstance(generador, Generador):
            if isinstance(self.expresion, Instruccion):
                valor = self.expresion.Ejecutar(arbol, tabla)
                if isinstance(valor, Error):
                    return valor
                if self.expresion.type != self.required_type:
                    return Error("Sintactico", "Se esperaba un valor tipo "+self.required_type.value+" y se obtuvo un valor tipo "+self.expresion.type.value, self.row, self.column)
                if tabla.get_variable(self.id) == None:
                    generador.insert_stack(tabla.size, valor.value)
                    if self.expresion.type == Tipos.STRING:
                        tabla.set_variable(self.id, self.expresion.type, True)
                    else:
                        tabla.set_variable(self.id, self.expresion.type, False)
                    if valor.is_temporal:
                        generador.set_unused_temp(valor.value)
                else:
                    variable = tabla.get_variable()
                    if variable !=None:
                        pass                        
    
    
        
    def getNodo(self) -> NodoAST:
        nodo = NodoAST('PRINT')
        
        return nodo