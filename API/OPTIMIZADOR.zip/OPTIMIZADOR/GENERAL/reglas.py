class Rule(object):

    def __init__(self,number, type, Rule, original, row, column):
        self.number = number
        self.type = type
        self.Rule = Rule
        self.original = original
        self.row = row
        self.column = column
        self.opt = ""
        